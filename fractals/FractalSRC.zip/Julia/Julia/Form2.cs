﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Julia
{
	public partial class Form2 : Form
	{
		public int N = 2;
		public double rmax = 2.0;
		public int kmax = 50;
		public int W = 600;
		public bool invert = false;
		public Color color = Color.Blue;
		public Color back = Color.White;
		public double cx=0.36,cy=0.36;
		public double size=4.0,minx=-2.0,miny=-2.0;

		public Bitmap bmp = new Bitmap(1,1);
		public int[,] M;

		public Form2()
		{
			InitializeComponent();
		}

		private void saveToolStripMenuItem_Click(object sender, EventArgs e)
		{
			if(saveFileDialog1.ShowDialog()==DialogResult.OK)
				bmp.Save(saveFileDialog1.FileName);
		}

		private void Form2_Shown(object sender, EventArgs e)
		{
			ClientSize = new Size(W,W);
			M = new int[W,W];
			calc();
			bmp = new Bitmap(W,W);
			draw();
		}

		private void Form2_Paint(object sender, PaintEventArgs e)
		{
			e.Graphics.DrawImage(bmp,0,0);
		}

		void calc()
		{
			Complex c = new Complex(),cn;
			int k;
			for(int i=0;i<W;i++)
			{
				for(int j=0;j<W;j++)
				{
					c.re = minx+(i*size)/(double)W;
					c.im = miny+(j*size)/(double)W;
					for(k=1;k<kmax;k++)
					{
						cn = c.pow(N);
						cn.re+=cx;
						cn.im+=cy;
						if(cn.re*cn.re+cn.im+cn.im>rmax*rmax)
							break;
						c = new Complex(cn);
					}
					M[i,j] = k;
				}
				this.Text = "Фрактал: Обработано "+(i+1).ToString()+" из "+W.ToString();
				Application.DoEvents();
			}
		}

		void draw()
		{
			this.Text = "Фрактал: Завершение...";
			Graphics g = Graphics.FromImage(bmp);
			g.Clear(back);	
			int col;
			for(int i=0;i<W;i++)
				for(int j=0;j<W;j++)
				{
					col = (M[i,j]*255)/kmax; //прозрачность цвета
					Pen p = new Pen(Color.FromArgb(col,color));
					g.DrawRectangle(p,i,j,1,1);
					p.Dispose();
				}
			g.Dispose();
			Refresh();
			this.Text = "Фрактал: Готово";
		}
	}
}
