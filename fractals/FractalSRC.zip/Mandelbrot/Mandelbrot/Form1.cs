﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Mandelbrot
{
	public partial class Form1 : Form
	{
		public Color col = Color.Blue, bgcol = Color.White;

		public Form1()
		{
			InitializeComponent();
		}

		private void button1_Click(object sender, EventArgs e)
		{
			Form2 f2 = new Form2();
			f2.W = (int)numericUpDown1.Value;
			f2.rmin = (double)numericUpDown2.Value;
			f2.N = (int)numericUpDown3.Value;
			f2.kmax = (int)numericUpDown4.Value;
			f2.size = Double.Parse(textBox1.Text);
			f2.minx = Double.Parse(textBox2.Text);
			f2.miny = Double.Parse(textBox3.Text);
			f2.back = bgcol;
			f2.color = col;
			f2.Show();
		}

		private void button2_Click(object sender, EventArgs e)
		{
			if(colorDialog1.ShowDialog()==DialogResult.OK)
				col = colorDialog1.Color;
		}

		private void button3_Click(object sender, EventArgs e)
		{
			if(colorDialog2.ShowDialog()==DialogResult.OK)
				bgcol = colorDialog2.Color;
		}

	}
}
