﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Mandelbrot
{
	public partial class Form2 : Form
	{

		public int W = 600;
		public double rmin = 2.0;
		public int kmax = 100;
		public int N = 2;
		public int[,] M;
		public double size=3.0, minx=-2.0, miny=-1.5;
		int[] bin;
		public bool invert = false;
		public Color color = Color.Blue;
		public Color back = Color.White;
		
		Bitmap bmp = new Bitmap(1,1);

		public Form2()
		{
			InitializeComponent();
		}

		void binomial(int N) //вычисление бинномиальных коэффициентов методом "треугольника Паскаля"
		{
			for(int i=1;i<=N;i++)
			{
				int[] nb = new int[i+1];
				nb[0]=1;
				for(int j=1;j<i;j++)
					nb[j] = bin[j-1]+bin[j];
				nb[i] = 1;
				bin = nb;
			}
		}

		void calc()
		{	
			for(int i=0;i<W;i++)
			{
				for(int j=0;j<W;j++)
				{
					double xk,yk,xn,yn,cx,cy;
					int k;
					cx=xk=minx+(size*i)/((double)W);
					cy=yk=miny+(size*j)/((double)W);
					for(k=1;k<kmax;k++)
					{
						xn=cx;
						yn=cy;
						for(int p=0;p<=N;p++) //вычисление степени комплексного числа
							if(p%2==0)
							{
								xn+=bin[p]*Math.Pow(xk,N-p)*Math.Pow(yk,p)*((p%4!=0 && p!=0)?-1.0:1.0);
							}else{
								yn+=bin[p]*Math.Pow(xk,N-p)*Math.Pow(yk,p)*(((p-1)%4!=0 && p!=1)?-1.0:1.0);
							}
						if(xn*xn+yn*yn>rmin*rmin) //условие остановки
							break;
						xk = xn;
						yk = yn;
					}
					M[i,j] = k;
				}
				this.Text = "Фрактал: Обработано "+(i+1).ToString()+" из "+W.ToString();
				Application.DoEvents();
			}
		}

		void draw()
		{		
			//инициализация 
			M = new int[W,W];
			bin = new int[]{1};
			binomial(N); //вычисление биномиальных коэффициентов
			//
			Graphics g = Graphics.FromImage(bmp);
			g.Clear(back);
			calc(); //вычисление

			//рисование изображения
			this.Text = "Фрактал: Завершение...";
			for(int i=0;i<W;i++)
				for(int j=0;j<W;j++)
				{
					int col = (M[i,j]*255)/kmax; //степень прозрачности цвета
					Pen p = new Pen(Color.FromArgb(col,color));
					g.DrawRectangle(p,i,j,1,1);
					p.Dispose();	
				}
			g.Dispose();
			Refresh();
			this.Text = "Фрактал: Готово";	
		}

		private void saveToolStripMenuItem_Click(object sender, EventArgs e)
		{
			if(saveFileDialog1.ShowDialog()==DialogResult.OK)
				bmp.Save(saveFileDialog1.FileName,System.Drawing.Imaging.ImageFormat.Png); //сохранить изображение в файл
		}

		private void Form2_Paint(object sender, PaintEventArgs e)
		{
			e.Graphics.DrawImage(bmp,0,0);
		}

		private void Form2_Shown(object sender, EventArgs e)
		{
			this.ClientSize = new Size(W,W);
			bmp = new Bitmap(W,W);
			
			draw();
			Refresh();
		}
	}
}
