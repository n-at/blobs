﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Drawing.Drawing2D;

namespace Newton
{
	public partial class Form2 : Form
	{
		public Bitmap bmp = new Bitmap(1,1);
		public int W = 600;
		public double rmin = 0.01;
		public int kmax = 80;
		public int [,] M;
		public double size = 2.0;
		public double minx = -1.0,miny=-1.0;
		public int N;
		public Color color = Color.Blue;
		public Color back = Color.White;

		public Form2()
		{
			InitializeComponent();
		}

		private void saveToolStripMenuItem_Click(object sender, EventArgs e)
		{
			if(saveFileDialog1.ShowDialog()==DialogResult.OK)
				bmp.Save(saveFileDialog1.FileName);
		}

		private void Form2_Paint(object sender, PaintEventArgs e)
		{
			e.Graphics.DrawImage(bmp,0,0);
		}

		private void Form2_Shown(object sender, EventArgs e)
		{
			this.ClientSize = new Size(W,W);
			bmp = new Bitmap(W,W);
			M = new int[W,W];
			calc(); //рассчитать
			draw(); //нарисовать
		}

		void calc()
		{
			double xt,yt;
			Complex c = new Complex();
			Complex cn = new Complex();
			Complex ct;
			int k;
			for(int i=0;i<W;i++)
			{
				for(int j=0;j<W;j++)
				{ //начальные значения
					c.re = minx+(i*size)/(double)W;
					c.im = miny+(j*size)/(double)W;
					for(k=0;k<kmax;k++)
					{
						//Вычисление c - (c^N - 1) / (c^(N - 1) * N)
						cn = c.pow(N)+(-1.0);
						cn = cn/((c.pow(N-1))*((double)N)); 
						cn = c-cn;
						ct = cn.pow(N);
						xt = ct.re;
						yt = ct.im;
						if(Math.Abs(xt*xt+yt*yt-1)<rmin*rmin) //условие остановки
							break;
						c = new Complex(cn);
					}
					M[i,j] = k;
				}
				this.Text = "Фрактал: Обработано "+(i+1).ToString()+" из "+W.ToString();
				Application.DoEvents();
			}
		}

		void draw()
		{
			this.Text = "Фрактал: Завершение...";
			Graphics g = Graphics.FromImage(bmp);
			g.Clear(back); //заливка фона
			int col;
			for(int i=0;i<W;i++)
				for(int j=0;j<W;j++)
				{
					col = (M[i,j]*255)/kmax; //вычисление прозрачности цвета в текущей точке
					Pen p = new Pen(Color.FromArgb(col,color));
					g.DrawRectangle(p,i,j,1,1);
					p.Dispose();
				}
			g.Dispose();
			Refresh();
			Text = "Фрактал: Готово";
		}
	}

}
