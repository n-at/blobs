﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Fern
{
	public partial class Form3 : Form
	{
		public int W = 600;
		public double eps = 1e-3;
		public int Side = 1;

		public int N = 10;
		public double k1=20.0,
			          k2=40.0,
					  m1=190.0,
					  m2=230.0,
					  m3=600.0,
					  phi0=-20*Math.PI/180.0,
					  phi1=-10*Math.PI/180.0,
					  phi2=-60*Math.PI/180.0,
					  phi3=-15*Math.PI/180.0;
		public bool random = false;
		Bitmap bmp = new Bitmap(1,1);
		public Color color = Color.Blue;
		public Color back = Color.White;
		Graphics g;
		Pen p;
		Random rnd = new Random();

		void draw(PointF p0, PointF p1)
		{
			g.DrawLine(p,p0.X,W-p0.Y,p1.X,W-p1.Y);
		}

		void fern(PointF p0, double h, double psi, int side, double del, int rec)
		{
			if(rec==0 || k2*h<del)
				return;

			double p1x,p1y,p2x,p2y;
			p1x = p0.X-(k1*h)*Math.Sin(psi);
			p1y = p0.Y+(k1*h)*Math.Cos(psi);

			p2x = p0.X-(k2*h)*Math.Sin(psi);
			p2y = p0.Y+(k2*h)*Math.Cos(psi); 

			PointF p1 = new PointF((float)p1x,(float)p1y);
			PointF p2 = new PointF((float)p2x,(float)p2y);

			draw(p0,p2);

			fern(p1,m1*h,psi-side*(phi1+phi0+(random?(rnd.Next(2000)/100.0-10.0)*Math.PI/180.0:0.0)),-side,del,rec-1);
			fern(p2,m2*h,psi+side*(phi2+phi0+(random?(rnd.Next(2000)/100.0-10.0)*Math.PI/180.0:0.0)),side,del,rec-1);
			fern(p2,m3*h,psi-side*(phi3-phi0+(random?(rnd.Next(2000)/100.0-10.0)*Math.PI/180.0:0.0)),side,del,rec-1);
		}

		public Form3()
		{
			InitializeComponent();
		}

		private void Form3_Load(object sender, EventArgs e)
		{
			
		}

		private void saveToolStripMenuItem_Click(object sender, EventArgs e)
		{
			if(saveFileDialog1.ShowDialog()==DialogResult.OK)
				bmp.Save(saveFileDialog1.FileName);
		}

		private void Form3_Paint(object sender, PaintEventArgs e)
		{
			e.Graphics.DrawImage(bmp,0,0);
		}

		private void Form3_Shown(object sender, EventArgs e)
		{
			ClientSize = new Size(W,W);
			bmp = new Bitmap(W,W);
			g = Graphics.FromImage(bmp);
			g.Clear(back);
			p = new Pen(color);

			fern(new PointF(W/2f,0f),W,0.0,Side,eps,N);
			g.Dispose();
			p.Dispose();
			Refresh();
		}
	}
}
