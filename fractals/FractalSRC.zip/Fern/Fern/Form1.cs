﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Fern
{
	public partial class Form1 : Form
	{
		public Form1()
		{
			InitializeComponent();
		}

		private void button1_Click(object sender, EventArgs e)
		{
			Form2 f2 = new Form2();
			f2.W = (int)numericUpDown1.Value;
			f2.kmax = (int)numericUpDown2.Value;
			f2.N = (int)numericUpDown3.Value;
			f2.color = colorDialog1.Color;
			f2.back = colorDialog2.Color;
			f2.Show();
		}

		private void button2_Click(object sender, EventArgs e)
		{
			colorDialog1.ShowDialog();
		}

		private void button3_Click(object sender, EventArgs e)
		{
			colorDialog2.ShowDialog();
		}

		private void button4_Click(object sender, EventArgs e)
		{
			Form3 f3 = new Form3();
			f3.W = (int)numericUpDown4.Value;
			f3.N = (int)numericUpDown5.Value;
			f3.Side = (int)numericUpDown6.Value;
			f3.phi0 = Double.Parse(textBox7.Text)*Math.PI/180.0;
			f3.phi1 = Double.Parse(textBox8.Text)*Math.PI/180.0;
			f3.phi2 = Double.Parse(textBox9.Text)*Math.PI/180.0;
			f3.phi3 = Double.Parse(textBox10.Text)*Math.PI/180.0;
			f3.eps = Double.Parse(textBox1.Text);
			f3.k1 = Double.Parse(textBox2.Text);
			f3.k2 = Double.Parse(textBox3.Text);
			f3.m1 = Double.Parse(textBox4.Text);
			f3.m2 = Double.Parse(textBox5.Text);
			f3.m3 = Double.Parse(textBox6.Text);
			f3.color = colorDialog1.Color;
			f3.back = colorDialog2.Color;
			f3.random = checkBox1.Checked;
			f3.Show();
		}

		private void label3_Click(object sender, EventArgs e)
		{

		}

		private void label2_Click(object sender, EventArgs e)
		{

		}
	}
}
