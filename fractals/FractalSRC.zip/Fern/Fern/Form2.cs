﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Fern
{
	public partial class Form2 : Form
	{
		public int W = 600;
		public int kmax = 20;
		public int N = 10000;

		public Bitmap bmp = new Bitmap(1,1);
		public Color color = Color.Green;
		public Color back = Color.Black;

		void draw()
		{
			bmp = new Bitmap(W,W);
			Graphics g = Graphics.FromImage(bmp);
			Pen p = new Pen(color);
			g.Clear(back);
			//---
			Random rnd = new Random();
			for(int i=0;i<N;i++)
			{
				float x = (float)(rnd.NextDouble()*0.5);
				float y = (float)(rnd.NextDouble()*0.5);
				double nx,ny;
				for(int k=0;k<kmax;k++)
				{
					double dice = rnd.NextDouble(); //получить случайное число
					if(dice<0.01)
					{
						nx = 0.0;
						ny = 0.16*y;
					}
					else if(dice<0.86)
					{
						nx = 0.85*x+0.04*y;
						ny = -0.04*x+0.85*y+1.6;
					}
					else if(dice<0.93)
					{
						nx = 0.2*x-0.26*y;
						ny = 0.23*x+0.22*y+1.6;
					}
					else
					{
						nx = -0.15*x+0.28*y;
						ny = 0.26*x+0.24*y+0.44;
					}
					x = (float)nx;
					y = (float)ny;
				}
				g.DrawRectangle(p,(float)(W-(5.0-x)*W/10.0),(float)((10.0-y)*W/10.0),0.5f,0.5f); //нарисовать с масштабированием
			}
		}

		public Form2()
		{
			InitializeComponent();
		}

		private void Form2_Shown(object sender, EventArgs e)
		{
			ClientSize = new Size(W,W);
			draw();
			Refresh();
		}

		private void Form2_Paint(object sender, PaintEventArgs e)
		{
			e.Graphics.DrawImage(bmp,0,0);
		}

		private void saveToolStripMenuItem_Click(object sender, EventArgs e)
		{
			if(saveFileDialog1.ShowDialog()==DialogResult.OK)
				bmp.Save(saveFileDialog1.FileName);
		}
	}
}
