﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Lindenmayer
{
	[Serializable]
	struct Rule
	{
		public char ch;
		public string str;
		public LOption option;
		public float param;

		public Rule(char C, string S, LOption opt)
		{
			ch = C;
			str = S;
			param = 0f;
			option = opt;
		}

		public Rule(char C, string S, float par, LOption opt)
		{
			ch = C;
			str = S;
			param = par;
			option = opt;
		}
	}
}
