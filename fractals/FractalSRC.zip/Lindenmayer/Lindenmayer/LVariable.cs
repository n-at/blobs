﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Lindenmayer
{
	public enum LOption{Nothing=0,Push=1,Pop=2,TurnRight=3,TurnLeft=4,DrawForward=5,DrawBackward=6,MoveForward=7,MoveBackward=8};

	public struct LVariable
	{
		public string value; //word
		public LOption option; 
		public float param; //step, angle, etc

		public LVariable(string val, LOption opt)
		{
			value = val;
			param = 0f;
			option = opt;
		}

		public LVariable(string val, float par, LOption opt)
		{
			value = val;
			param = par;
			option = opt;
		}
	}
}
