﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Lindenmayer
{
	struct TurtleState
	{
		public float x,y,angle;
		public TurtleState(float X, float Y, float A)
		{
			x = X;
			y = Y;
			angle = A;
		}
		public TurtleState(TurtleState T)
		{
			x = T.x;
			y = T.y;
			angle = T.angle;
		}
	}
}
