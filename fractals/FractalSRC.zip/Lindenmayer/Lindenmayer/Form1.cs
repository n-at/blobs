﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace Lindenmayer
{
	public partial class Form1 : Form
	{
		List<Rule> rules = new List<Rule>();

		public Form1()
		{
			InitializeComponent();
		}

		private void Form1_Load(object sender, EventArgs e)
		{
			rules.Add(new Rule('[',"[",LOption.Push));
			rules.Add(new Rule(']',"]",LOption.Pop));
			rules.Add(new Rule('+',"+",25f,LOption.TurnRight));
			rules.Add(new Rule('-',"-",-25f,LOption.TurnRight));
			rules.Add(new Rule('X',"F-[[X]+X]+F[+FX]-X",LOption.Nothing));
			rules.Add(new Rule('F',"FF",10f,LOption.DrawForward));
			RenderList();
		}

		private void button1_Click(object sender, EventArgs e) //draw
		{
			Form2 f2 = new Form2();
			f2.W = (int)numericUpDown2.Value;
			f2.H = (int)numericUpDown3.Value;
			f2.kmax = (int) numericUpDown1.Value;
			f2.canvasRot = (float)numericUpDown4.Value;
			f2.sx = (float)Double.Parse(textBox1.Text);
			f2.sy = (float)Double.Parse(textBox2.Text);
			f2.axiom = textBox4.Text;

			Dictionary<Char,LVariable> dict = new Dictionary<char,LVariable>();
			foreach(Rule R in rules)
				if(!dict.ContainsKey(R.ch))
					dict.Add(R.ch,new LVariable(R.str,R.param,R.option));
			f2.rules = dict;

			f2.color = colorDialog1.Color;
			f2.back = colorDialog2.Color;
			f2.pwidth = (int)numericUpDown5.Value;

			f2.Show();
		}

		private void button2_Click(object sender, EventArgs e)
		{
			colorDialog1.ShowDialog(); //main color
		}

		private void button3_Click(object sender, EventArgs e)
		{
			colorDialog2.ShowDialog(); //background color
		}

		void RenderList()
		{
			listBox1.Items.Clear();
			foreach(Rule R in rules)
			{
				string s="";
				string val = R.param.ToString();
				switch(R.option)
				{
					case LOption.Nothing: s = ""; break;
					case LOption.Push: s = "(В стек)"; break;
					case LOption.Pop: s = "(Из стека)"; break;
					case LOption.TurnRight: s = "(Поворот "+val+")"; break;
					case LOption.TurnLeft: s = "(Поворот Л "+val+")"; break;
					case LOption.DrawForward: s = "(Рисовать "+val+")"; break;
					case LOption.DrawBackward: s = "(Рисовать Н "+val+")"; break;
					case LOption.MoveForward: s = "(Идти "+val+")"; break;
					case LOption.MoveBackward: s = "(Идти Н "+val+")"; break;
				}
				listBox1.Items.Add(R.ch.ToString()+" ► "+R.str+"  "+s);
			}
		}

		void addRule()
		{
			Form3 f3 = new Form3();
			if(f3.ShowDialog()==DialogResult.OK)
			{
				if(f3.textBox1.Text.Length==0)
				{
					MessageBox.Show("Переменная не определена");
					return ;
				}
				Rule R = new Rule(f3.textBox1.Text[0],f3.textBox2.Text,f3.value,f3.option);
				rules.Add(R);
				RenderList();
			}
		}

		int correctSelection()
		{
			int sel = listBox1.SelectedIndex;
			if(sel<0 || sel>=listBox1.Items.Count)
			{
				MessageBox.Show("Выберите правило");
				return -1;
			}
			return sel;
		}

		void deleteRule()
		{
			int sel = correctSelection();
			if(sel<0) return;
			rules.RemoveAt(sel);
			RenderList();
		}

		void editRule()
		{
			int sel = correctSelection();
			if(sel<0) return;

			Form3 f3 = new Form3();
			f3.textBox1.Text = rules[sel].ch.ToString();
			f3.textBox2.Text = (string)rules[sel].str.Clone();
			f3.option = rules[sel].option;
			f3.value = rules[sel].param;

			if(f3.ShowDialog()==DialogResult.OK)
			{
				if(f3.textBox1.Text.Length==0)
				{
					MessageBox.Show("Переменная не определена");
					return;
				}
				Rule R = new Rule(f3.textBox1.Text[0],f3.textBox2.Text,f3.value,f3.option);
				rules[sel] = R;
				RenderList();
			}
		}

		void saveToFile(string filename)
		{
			FileStream fs = new FileStream(filename,FileMode.Create,FileAccess.Write);
			BinaryFormatter bf = new BinaryFormatter();
			bf.Serialize(fs,numericUpDown1.Value);
			bf.Serialize(fs,numericUpDown2.Value);
			bf.Serialize(fs,numericUpDown3.Value);
			bf.Serialize(fs,numericUpDown4.Value);
			bf.Serialize(fs,textBox1.Text);
			bf.Serialize(fs,textBox2.Text);
			bf.Serialize(fs,textBox4.Text); //save axiom
			bf.Serialize(fs,rules);
			fs.Close();
		}

		void loadFromFile(string filename)
		{
			FileStream fs = new FileStream(filename,FileMode.Open, FileAccess.Read);
			BinaryFormatter bf = new BinaryFormatter();
			numericUpDown1.Value = (Decimal)bf.Deserialize(fs);
			numericUpDown2.Value = (Decimal)bf.Deserialize(fs);
			numericUpDown3.Value = (Decimal)bf.Deserialize(fs);
			numericUpDown4.Value = (Decimal)bf.Deserialize(fs);
			textBox1.Text = (String)bf.Deserialize(fs);
			textBox2.Text = (String)bf.Deserialize(fs);
			textBox4.Text = (String)bf.Deserialize(fs);
			rules = (List<Rule>)bf.Deserialize(fs);
			fs.Close();
			RenderList();
		}

		private void button6_Click(object sender, EventArgs e) //Delete
		{
			deleteRule();
		}

		private void button4_Click(object sender, EventArgs e) //Add
		{
			addRule();
		}

		private void button5_Click(object sender, EventArgs e) //Edit
		{
			editRule();
		}

		private void listBox1_DoubleClick(object sender, EventArgs e)
		{
			editRule();
		}

		private void button7_Click(object sender, EventArgs e)
		{
			rules.Clear();
			RenderList();
		}

		private void button9_Click(object sender, EventArgs e)
		{
			if(saveFileDialog1.ShowDialog()==DialogResult.OK)
				saveToFile(saveFileDialog1.FileName);
		}

		private void button8_Click(object sender, EventArgs e)
		{
			if(openFileDialog1.ShowDialog()==DialogResult.OK)
				loadFromFile(openFileDialog1.FileName);	
		}
	}
}
