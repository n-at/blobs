﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Lindenmayer
{
	public partial class Form2 : Form
	{
		public int W = 800, H = 600;
		public int kmax = 5;
		public string axiom = "X";
		public Dictionary<Char,LVariable> rules = new Dictionary<Char,LVariable>();
		public float sx=0f,sy=600f;
		public float canvasRot = -50f;
		public int pwidth = 1;

		Bitmap bmp = new Bitmap(1,1);
		public Color color = Color.Olive;
		public Color back = Color.White;

		public bool abort = false;

		public Form2()
		{
			InitializeComponent();
		}

		private void Form2_Shown(object sender, EventArgs e)
		{
			ClientSize = new Size(W,H);
			bmp = new Bitmap(W,H);
			calc();
			Refresh();
		}

		private void Form2_Paint(object sender, PaintEventArgs e)
		{
			e.Graphics.DrawImage(bmp,0,0);		
		}

		void calc()
		{
			Text = "L-Система: Рисование";
			StringBuilder sb;
			for(int k=0;k<kmax;k++)
			{
				sb = new StringBuilder();
				foreach(char c in axiom) //перебрать символы аксиомы по порядку
				{
					if(!rules.ContainsKey(c))
						sb.Append(c); //константа
					else
						sb.Append(rules[c].value); //переменная
				}
				if(abort)
					return;
				axiom = sb.ToString(); //обновить аксиому
				draw();
				Refresh();
				Application.DoEvents();
			}
			Text = "L-Система: Готово";
		}

		void draw()
		{
			Graphics g = Graphics.FromImage(bmp);
			g.TranslateTransform(sx,sy);
			g.RotateTransform(canvasRot);
			g.Clear(back);
			Pen p = new Pen(color,pwidth);
			//Automaton
			Stack<TurtleState> st = new Stack<TurtleState>(); //стек координат
			TurtleState ts = new TurtleState();
			ts.x = 0;
			ts.y = 0;
			ts.angle = 0f;
			LVariable lvar;
			foreach(char c in axiom)
			{
				if(!rules.ContainsKey(c))
					continue; //пропуск константы
				lvar = rules[c];
				switch(lvar.option) //команды "черепашьей графики"
				{
					case LOption.Push: //добавить координаты в стек
						st.Push(ts);
						ts = new TurtleState(ts);
					break;
					case LOption.Pop: //восстановить координаты из стека
						ts = new TurtleState(st.Pop());	
					break;
					case LOption.TurnRight: ts.angle+=(float)(lvar.param*Math.PI/180.0); break; //поворот
					case LOption.TurnLeft:  ts.angle-=(float)(lvar.param*Math.PI/180.0); break; //поворот влево (не используется)
					case LOption.DrawForward: //нарисовать линию
						{
							float x = (float)(ts.x+lvar.param*Math.Cos(ts.angle));
							float y = (float)(ts.y+lvar.param*Math.Sin(ts.angle));
							g.DrawLine(p,ts.x,ts.y,x,y);
							ts.x = x;
							ts.y = y;
						}
					break;
					case LOption.DrawBackward: //нарисовать линию, двигаясь назад (не используется)
						{
							float x = (float)(ts.x-lvar.param*Math.Cos(ts.angle));
							float y = (float)(ts.y-lvar.param*Math.Sin(ts.angle));
							g.DrawLine(p,ts.x,ts.y,x,y);
							ts.x = x;
							ts.y = y;
						}
					break;
					case LOption.MoveForward: //переместиться
						{
							float x = (float)(ts.x+lvar.param*Math.Cos(ts.angle));
							float y = (float)(ts.y+lvar.param*Math.Sin(ts.angle));
							ts.x = x;
							ts.y = y;
						}
					break;
					case LOption.MoveBackward: //переместиться назад (не используется)
						{
							float x = (float)(ts.x-lvar.param*Math.Cos(ts.angle));
							float y = (float)(ts.y-lvar.param*Math.Sin(ts.angle));
							ts.x = x;
							ts.y = y;
						}
					break;
				}
				if(abort)
					return;
			}
			p.Dispose();
			g.Dispose();
		}

		private void saveToolStripMenuItem_Click(object sender, EventArgs e)
		{
			if(saveFileDialog1.ShowDialog()==DialogResult.OK)
				bmp.Save(saveFileDialog1.FileName);
		}

		private void Form2_FormClosed(object sender, FormClosedEventArgs e)
		{
			abort = true;
		}
	}
}
