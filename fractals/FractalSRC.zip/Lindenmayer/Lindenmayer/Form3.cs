﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Lindenmayer
{
	public partial class Form3 : Form
	{
		public LOption option = LOption.Nothing;
		public float value = 0f;

		public Form3()
		{
			InitializeComponent();
		}

		private void Form3_Shown(object sender, EventArgs e)
		{
			switch(option)
			{
				case LOption.Nothing:		
					radioButton1.Checked = true;		
					break;
				case LOption.Push:			
					radioButton2.Checked = true;		
					break;
				case LOption.Pop:			
					radioButton3.Checked = true;		
					break;
				case LOption.TurnRight:		
					radioButton4.Checked = true;		
					break;
				case LOption.TurnLeft:
					radioButton4.Checked = true;		
					option = LOption.TurnRight;
					value = -value;
					break;
				case LOption.DrawForward:	
					radioButton6.Checked = true;		
					break;
				case LOption.DrawBackward:	
					radioButton6.Checked = true;		
					option = LOption.DrawForward;
					value = -value;
					break;
				case LOption.MoveForward:	
					radioButton8.Checked = true;		
					break;
				case LOption.MoveBackward:	
					radioButton8.Checked = true;		
					option = LOption.MoveForward;
					value = -value;
					break;
			}
			textBox3.Text = value.ToString();
		}

		private void radioButton1_CheckedChanged(object sender, EventArgs e)
		{
			if(radioButton1.Checked)
				option = LOption.Nothing;
		}

		private void radioButton2_CheckedChanged(object sender, EventArgs e)
		{
			if(radioButton2.Checked)
				option = LOption.Push;
		}

		private void radioButton3_CheckedChanged(object sender, EventArgs e)
		{
			if(radioButton3.Checked)
				option = LOption.Pop;
		}

		private void radioButton4_CheckedChanged(object sender, EventArgs e)
		{
			if(radioButton4.Checked)
				option = LOption.TurnRight;
		}

		private void radioButton6_CheckedChanged(object sender, EventArgs e)
		{
			if(radioButton6.Checked)
				option = LOption.DrawForward;
		}


		private void radioButton8_CheckedChanged(object sender, EventArgs e)
		{
			if(radioButton8.Checked)
				option = LOption.MoveForward;
		}

		private void button1_Click(object sender, EventArgs e)
		{
			value = (float)Double.Parse(textBox3.Text);
		}
	}
}
